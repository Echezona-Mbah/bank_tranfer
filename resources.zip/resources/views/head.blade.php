<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from enemabank.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 12 Jan 2024 19:12:35 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0, shrink-to-fit=no" />
<link href="demo/html/payyed/images/logo.jpg" rel="icon" />
<title>swiftshieldbank</title>
<meta name="description" content="SwiftShield Bank is one of the first of global virtual banking services, which, in fact, was created as a mobile application from an organization that is not a bank, but promotes its services as banking, relying on legal and processing support Partner bank." />
<meta name="author" content="harnishdesign.net" />

<link rel="stylesheet" href="{{asset('http://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap')}}" />

<link rel="stylesheet" type="text/css" href="{{asset('demo/html/payyed/vendor/bootstrap/css/bootstrap.min.css')}}" />
<link rel="stylesheet" type="text/css" href="{{asset('demo/html/payyed/vendor/font-awesome/css/all.min.css')}}" />
<link rel="stylesheet" type="text/css" href="{{asset('demo/html/payyed/vendor/owl.carousel/assets/owl.carousel.min.css')}}" />
<link rel="stylesheet" type="text/css" href="{{asset('demo/html/payyed/css/stylesheet.css')}}" />

<link rel="stylesheet" href="{{asset('css/style.css')}}">
</head>
<script src="../code.tidio.co_443/7ramfzdiwzi6kyphhcyowzuzhzxtkbmn.js" async></script>
<body>

<div id="preloader">
<div data-loader="dual-ring"></div>
</div>


<div id="main-wrapper">

<header id="header">
<div class="container">
<div class="header-row">
<div class="header-column justify-content-start">

<div class="logo me-3">
<a class="d-flex" href="index.html" title="swiftshieldbank - HTML Template"><img src="demo/html/payyed/images/logo.jpg" width="250px" height="70px" alt="swiftshieldbank" /></a>
</div>


<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#header-nav">
<span></span> <span></span> <span></span>
</button>


<nav class="primary-menu navbar navbar-expand-lg">
<div id="header-nav" class="collapse navbar-collapse">
<ul class="navbar-nav me-auto">
<li>
<a href="about">About Us</a
                                            >
</li>
<li>
<a href="login">Fees</a
                                            >
</li>
<li>
<a href="login">Help</a
                                            >
</li>
<li>
<a href="contact">Contact Us</a
                                            >
</li>
<li class="dropdown dropdown-mega"> <a class="dropdown-toggle" href="#">More</a>
<ul class="dropdown-menu">
<li>
<div class="dropdown-mega-content">
<div class="row">
<div class="col-lg"> <span class="sub-title">Account</Span>
<ul class="dropdown-mega-submenu">
<li><a class="dropdown-item" href="register">My Profile</a></li>
<li><a class="dropdown-item" href="login">Security</a></li>
<li><a class="dropdown-item" href="login">Payment Methods</a></li>
<li><a class="dropdown-item" href="login">Notifications</a></li>
<li class="dropdown"><a class="dropdown-item dropdown-toggle" href="login">Login</a>
<ul class="dropdown-menu">
<li><a class="dropdown-item" href="login">Login Page</a></li>
</ul>
</li>
<!-- <li class="dropdown"><a class="dropdown-item dropdown-toggle" href="#">Signup</a> -->
<ul class="dropdown-menu">
<!-- <li><a class="dropdown-item" href="signup.php">Signup Page</a></li> -->
</ul>
</li>
</ul>
</div>
<div class="col-lg"> <span class="sub-title">Dashboard</Span>
<ul class="dropdown-mega-submenu">
<li><a class="dropdown-item" href="login">Dashboard</a></li>
<li><a class="dropdown-item" href="login">Transactions</a></li>
<li class="dropdown"><a class="dropdown-item dropdown-toggle" href="#">Send Money</a>
<ul class="dropdown-menu">
<li><a class="dropdown-item" href="login">Send Money</a></li>
<li><a class="dropdown-item" href="login">Send Money Confirm</a></li>
<li><a class="dropdown-item" href="login">Send Money Success </a></li>
</ul>
</li>
<li class="dropdown"><a class="dropdown-item dropdown-toggle" href="#">Request Money</a>
<ul class="dropdown-menu">
<li><a class="dropdown-item" href="login">Request Money</a></li>
<li><a class="dropdown-item" href="login">Request Money Confirm</a></li>
<li><a class="dropdown-item" href="login">Request Money Success </a></li>
</ul>
</li>
<li class="dropdown"><a class="dropdown-item dropdown-toggle" href="#">Deposit Money</a>
<ul class="dropdown-menu">
<li><a class="dropdown-item" href="login">Deposit Money</a></li>
<li><a class="dropdown-item" href="login">Deposit Money Confirm</a></li>
<li><a class="dropdown-item" href="login">Deposit Money Success </a></li>
</ul>
</li>
<li class="dropdown"><a class="dropdown-item dropdown-toggle" href="#">Withdraw Money</a>
<ul class="dropdown-menu">
<li><a class="dropdown-item" href="login">Withdraw Money</a></li>
<li><a class="dropdown-item" href="login">Withdraw Money Confirm</a></li>
<li><a class="dropdown-item" href="login">Withdraw Money Success </a></li>
</ul>
</li>
<li><a class="dropdown-item" href="login">Notifications</a></li>
</ul>
</div>
</div>
</div>
</li>
</ul>
</li>
</ul>
</div>
</nav>

</div>
<div class="header-column justify-content-end">

<nav class="login-signup navbar navbar-expand">
<ul class="navbar-nav">
<!-- <li>
<a href="login.php">Login</a
                                        >
</li> -->
<li class="align-items-center h-auto ms-sm-3">
<a class="btn btn-primary" href="login">Login IN</a
                                        >
</li>
</ul>
</nav>

</div>
</div>
</div>
</header>