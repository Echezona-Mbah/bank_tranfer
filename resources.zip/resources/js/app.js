import './bootstrap';

import Alpine from 'alpinejs';
window.Swal = require('sweetalert2');

window.Alpine = Alpine;

Alpine.start();
